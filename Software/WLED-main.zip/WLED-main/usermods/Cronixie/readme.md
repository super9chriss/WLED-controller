# Cronixie clock usermod

This usermod supports driving the Cronixie M and L clock kits by Diamex.

## Installation 

Compile and upload after adding `Cronixie` to `custom_usermods` of your PlatformIO environment.  
Make sure the Auto Brightness Limiter is enabled at 420mA (!) and configure 60 WS281x LEDs.