# Enclosure and PCB

## IP67 rated enclosure
![Enclosure](controller.jpg)

## PCB
![PCB](pcb.png)
