# ADS1115 16-Bit ADC with four inputs

This usermod will read from an ADS1115 ADC. The voltages are displayed in the Info section of the web UI.

Configuration is performed via the Usermod menu. There are no parameters to set in code!

## Installation 

Add 'ADS1115' to `custom_usermods` in your platformio environment.

